ZENITH PRESTIGE STORE UPGRADE

This package contains index.html with a black, gold and white theme and a simple shopping cart.

Features:
- Four product categories: Free Fire accounts, diamonds/top-ups, gaming services and tournament entry
- Search and category filters
- Add to cart, quantity controls, remove items and clear cart
- WhatsApp order message generated from the cart
- Existing WhatsApp channel and chat links included
- Tournament/event cards and gaming news
- Mobile-friendly layout

IMPORTANT BEFORE DEPLOYING:
1. Open index.html and check the CONFIG links are still the WhatsApp links you want to use.
2. Edit PRODUCTS to add accurate product details and confirmed prices. Prices currently show as “Price to be confirmed” and the cart will not pretend the total is known.
3. Edit EVENTS and NEWS with verified information.
4. Save, then update index.html in your GitHub repository so Netlify can deploy it.

This is a static site. It has no online admin dashboard, database, automatic stock tracking or payment processing. The cart only prepares an order message; confirm price, availability and payment directly. Check the game's current rules before advertising account transfers. Never publish passwords or recovery codes.
